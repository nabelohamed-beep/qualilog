# QualiLog

Outil pédagogique, sans valeur réglementaire.

Aide à qualifier et classer un logiciel de santé (ou un équipement) au regard du règlement (UE) 2017/745 : qualification module par module, périmètre du dispositif médical, classe (règle 11, annexe VIII), conséquences, rapport imprimable, sauvegarde et reprise d'un passage.

## Contenu
- `index.html` : l'outil complet (un seul fichier, aucune dépendance).

## Mise en ligne (GitHub Pages)
Settings → Pages → Source : branche `main`, dossier `/ (root)`.

## Limite connue
L'analyse par IA et le pré-remplissage utilisent une fonction propre à claude.ai. Hors de claude.ai, l'outil retombe sur une estimation par mots-clés. Pour garder l'IA en ligne, il faudra un relais serveur portant une clé API (jamais dans le HTML).
